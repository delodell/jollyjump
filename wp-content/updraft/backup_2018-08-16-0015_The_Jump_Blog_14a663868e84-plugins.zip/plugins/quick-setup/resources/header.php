<?php

/**
 * Copyright 2013 Go Daddy Operating Company, LLC. All Rights Reserved.
 */

// Make sure it's wordpress
if ( !defined( 'ABSPATH' ) )
	die( 'Forbidden' );

?>
<script type="text/javascript">
	var gd_quicksetup_img_dir = '<?php echo plugins_url( 'quick-setup/images' ); ?>';
</script>
<div class="wrap">
	<div class="q-setup-gd-icn"><br/></div>
	<h2 class="page-title"><?php _e( 'Go Daddy Quick Setup', 'gd_quicksetup' ); ?></h2>
	

	

