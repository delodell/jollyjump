<?php

/**
 * Copyright 2013 Go Daddy Operating Company, LLC. All Rights Reserved.
 */

// Make sure it's wordpress
if ( !defined( 'ABSPATH' ) )
	die( 'Forbidden' );

_e( 'Quick Setup needs access to install your selected theme and plugins via FTP. These credentials are <strong><em>never</em></strong> stored or transmitted.', 'gd_quicksetup' );
